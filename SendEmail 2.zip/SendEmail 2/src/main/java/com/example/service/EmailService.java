package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.domain.User;


@Service
public class EmailService {
	 private JavaMailSender javaMailSender;
	 
	 @Autowired
	 public EmailService(JavaMailSender javaMailSender){
		 this.javaMailSender = javaMailSender;
	 }
	 
	 public void sendEmail(User user) throws MailException {
		 SimpleMailMessage mail= new SimpleMailMessage();
		 mail.setFrom(“aaaa.sa@xyz.com");
		 System.out.println("****************"+user.getTo().toArray(new String[user.getTo().size()])+"****************");
	 String[] toArray = user.getTo().toArray(new String[user.getTo().size()]);
	//	 Object[] toArray = (user.getTo().toArray());

		 mail.setTo(toArray);
//		 for(String str:user.getTo()){
//			 mail.setTo(str);	
//	 }
			 mail.setSubject(user.getSubject());
			 mail.setText(user.getBody());

			 	 
		 javaMailSender.send(mail);
	 }
}
