package com.example.controller;



import java.awt.PageAttributes.MediaType;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.User;
import com.example.service.EmailService;

@RestController
public class SendEmailController {

	private Logger logger=LoggerFactory.getLogger(SendEmailController.class);
	
	@Autowired
	EmailService emailService;

	@RequestMapping("/gmailSignup")
	public String signUp() {
		return "Success";
	}

	@RequestMapping(value= "/signup-success", method = RequestMethod.POST, consumes = org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE, produces = org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE)
	public String signupSuccess(@RequestBody User user) throws Exception {

//		User user = new User();
//		user.setFirstName("varsha");
//		user.setLastName("aware");
//		user.setEmailAddress("varsha.aware1205@gmail.com");
		//String[] mail = {"varsha.aware1205@gmail.com","swathimbhat93@gmail.com","kamzkzta@gmail.com"};
		// send notification
		try {
			
			emailService.sendEmail(user);
			

		} catch (MailException e) {
			logger.info("Error" +e.getMessage());
		}

		return "Thanks for registration";
	}
}
